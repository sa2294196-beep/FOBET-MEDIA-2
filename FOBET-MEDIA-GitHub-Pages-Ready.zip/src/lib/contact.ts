export const WHATSAPP_NUMBER = "917600867915";
export const WHATSAPP_DISPLAY = "+91 7600 867 915";
export const WHATSAPP_LINK = `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(
  "Hi Fobet Media! I'd like to know more about your personal branding packages.",
)}`;