// GitHub Pages deployment configuration for FOBET-MEDIA
// The Lovable/TanStack wrapper already provides the Start, React, Tailwind,
// and Nitro plugins. We only override the Nitro runtime for prerendering.
import { defineConfig } from "@lovable.dev/vite-tanstack-config";
import { nitro } from "nitro/vite";

export default defineConfig({
  tanstackStart: {
    server: { entry: "server" },
    prerender: {
      enabled: true,
      autoSubfolderIndex: true,
      autoStaticPathsDiscovery: true,
      crawlLinks: true,
      failOnError: true,
    },
  },
  vite: {
    base: "/FOBET-MEDIA/",
    plugins: [nitro({ preset: "node-server" })],
  },
});
